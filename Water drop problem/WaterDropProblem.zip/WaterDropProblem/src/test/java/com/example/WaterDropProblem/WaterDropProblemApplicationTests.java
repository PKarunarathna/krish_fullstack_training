package com.example.WaterDropProblem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterDropProblemApplicationTests {

	@Test
	void contextLoads() {
	}

}
