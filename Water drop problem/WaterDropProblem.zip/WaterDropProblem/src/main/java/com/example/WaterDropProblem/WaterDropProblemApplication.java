package com.example.WaterDropProblem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterDropProblemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaterDropProblemApplication.class, args);
	}

}
