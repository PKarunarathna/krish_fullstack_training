package com.example.builderpattern.builderpattern.builder;

public class Application {

    public static void main(String[] args){

        CarTelescopic1 carTelescopic1=new CarTelescopic1("full");
        System.out.println(carTelescopic1);
        
    }

}
