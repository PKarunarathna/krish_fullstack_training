package com.example.chainofResponsibility.chainof.Responsibility;

public abstract  class Handler {
    protected Handler successor;


    public void setSuccessor(Handler successor) {
        this.successor = successor;
    }

    public abstract double applyTax(Invoice invoice);

   /* public void successor(VAT vat) {
    }*/
}
