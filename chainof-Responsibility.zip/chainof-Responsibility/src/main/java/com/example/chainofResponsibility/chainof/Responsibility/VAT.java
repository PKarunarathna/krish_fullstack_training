package com.example.chainofResponsibility.chainof.Responsibility;

public class VAT extends Handler {


    @Override
    public double applyTax(Invoice invoice) {
        invoice.setTax(invoice.getAmount()*0.01);
        if(invoice.getAmount()<=100){
            return invoice.getTax();
        }
        else {
            return successor.applyTax(invoice);
        }
    }
}
