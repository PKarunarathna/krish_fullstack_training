package com.example.chainofResponsibility.chainof.Responsibility;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChainofResponsibilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChainofResponsibilityApplication.class, args);
	}

}
