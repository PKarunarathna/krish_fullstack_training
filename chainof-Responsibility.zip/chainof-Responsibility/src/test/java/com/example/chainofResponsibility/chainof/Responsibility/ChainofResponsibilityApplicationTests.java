package com.example.chainofResponsibility.chainof.Responsibility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChainofResponsibilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
