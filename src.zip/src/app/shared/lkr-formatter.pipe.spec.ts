import { LkrFormatterPipe } from './lkr-formatter.pipe';

describe('LkrFormatterPipe', () => {
  it('create an instance', () => {
    const pipe = new LkrFormatterPipe();
    expect(pipe).toBeTruthy();
  });
});
