package com.dilani.renntcloud.auth.authserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
