package com.dilani.demo.controller;

import com.dilani.demo.model.Student;
import com.dilani.demo.servicer.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class MainController {

    @Autowired
    StudentService studentService;

    //This method can handle both GET & POST requests ,but If we declare method as GET it gives error as method not allowed
    //for post request
    @RequestMapping(value="/hello", method = RequestMethod.GET)
    public String greeting() {
        return "Hello Spring Boot";
    }

    @RequestMapping(value="/hello", method = RequestMethod.POST)
    public String greetingPost() {
        return "Hello Spring Boot from post method";
    }

    @RequestMapping(value="/student", method = RequestMethod.POST)
    public Student save(@RequestBody Student student)
    {
     return  studentService.save(student);
    }

 @RequestMapping(value = "/student", method = RequestMethod.GET)
    public ResponseEntity<Student> fetchStudent (@RequestParam int id){
        Student student =studentService.fetchStudentById(id);
        if(student==null){
           return  ResponseEntity.notFound().build();

        }
        else{
            return  ResponseEntity.ok().body(student);
        }
    }
}
