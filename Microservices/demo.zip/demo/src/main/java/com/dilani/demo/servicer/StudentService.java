package com.dilani.demo.servicer;


import com.dilani.demo.model.Student;

public interface StudentService {

    Student save(Student student);

    Student fetchStudentById(int id);
}
