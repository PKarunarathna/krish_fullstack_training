package com.dilani.rentcloud.profileservice.service;
import com.dilani.rentcloud.commons.model.Customer;
public interface CustomerService {


    Customer  save(Customer customer);
}
