package com.example.prototypepattern.prototypepattern;

public class Bus extends Vehicle{

    private int numOfSeats;

    public int getNumOfSeats() {
        return numOfSeats;
    }

    public void setNumOfSeats(int numOfSeats) {
        this.numOfSeats = numOfSeats;
    }

    @Override
    public String toString() {
        return "Bus{" +
                "numOfSeats=" + numOfSeats +
                '}';
    }
}
