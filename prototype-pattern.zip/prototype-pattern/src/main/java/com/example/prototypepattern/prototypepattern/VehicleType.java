package com.example.prototypepattern.prototypepattern;

public enum VehicleType {
    CAR,BUS
}
