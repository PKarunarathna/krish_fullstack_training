package com.example.prototypepattern.prototypepattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrototypePatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
