package com.dilani.rentcloud.configlocal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigLocalApplicationTests {

	@Test
	void contextLoads() {
	}

}
