package com.dilani.training.salesmanager.service;

import com.dilani.training.salesmanager.model.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> getAllEmployees();
}
