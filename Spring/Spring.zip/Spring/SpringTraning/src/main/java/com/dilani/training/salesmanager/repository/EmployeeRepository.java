package com.dilani.training.salesmanager.repository;

import com.dilani.training.salesmanager.model.Employee;
import com.dilani.training.salesmanager.model.Employee;

import java.util.List;

public interface EmployeeRepository {
    List<Employee> getAllEmployees();
}
