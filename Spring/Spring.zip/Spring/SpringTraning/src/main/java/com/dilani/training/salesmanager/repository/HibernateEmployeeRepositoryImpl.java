package com.dilani.training.salesmanager.repository;

import com.dilani.training.salesmanager.model.Employee;

import java.util.ArrayList;
import java.util.List;

public class HibernateEmployeeRepositoryImpl implements EmployeeRepository {

    @Override
    public List<Employee> getAllEmployees(){
        List<Employee> employees = new ArrayList<>();

        Employee employee = new Employee();
        employee.setEmployeeName("Dilani");
        employee.setEmployeeLocation("Kandy");
        employees.add(employee);

        return employees;

    }

}
