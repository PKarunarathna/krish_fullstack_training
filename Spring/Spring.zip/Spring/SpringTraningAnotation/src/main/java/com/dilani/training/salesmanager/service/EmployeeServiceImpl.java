package com.dilani.training.salesmanager.service;

import com.dilani.training.salesmanager.model.Employee;
import com.dilani.training.salesmanager.repository.EmployeeRepository;
import com.dilani.training.salesmanager.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

//    EmployeeRepository employeeRepository = new HibernateEmployeeRepositoryImpl();
    @Autowired
   EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(){
        System.out.println("Default construtor executed");
    }

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        System.out.println("Overloaded construtor executed");
        this.employeeRepository = employeeRepository;
    }

    //    create setter for above reference

    @Autowired
    public void setEmployeeRepository(EmployeeRepository employeeRepository) {
        System.out.println("Setter injection fired");
        this.employeeRepository = employeeRepository;
    }

    //    create getter for above reference
    public EmployeeRepository getEmployeeRepository() {
        return employeeRepository;
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.getAllEmployees();
    }
}
