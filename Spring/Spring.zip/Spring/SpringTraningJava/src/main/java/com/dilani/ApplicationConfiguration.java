package com.dilani;

import com.dilani.training.salesmanager.repository.EmployeeRepository;
import com.dilani.training.salesmanager.repository.HibernateEmployeeRepositoryImpl;
import com.dilani.training.salesmanager.service.EmployeeService;
import com.dilani.training.salesmanager.service.EmployeeServiceImpl;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@ComponentScan("com.dilani")
@PropertySource("application.properties")
public class ApplicationConfiguration {

    private EmployeeRepository employeeService;

    @Bean(name= "employeeService")
    //@Scope("singleton")
    @Scope("prototype")
    public EmployeeService getEmployeeService(){
        EmployeeServiceImpl employeeService=new EmployeeServiceImpl();
        employeeService.setEmployeeRepository(getEmployeeRepository());
        return  employeeService;
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer getPropertySourcesPlaceholderConfigurer(){
        return new PropertySourcesPlaceholderConfigurer();

    }

    private EmployeeRepository getEmployeeRepository() {
        return employeeService;
    }
/*
    @Bean(name= "employeeRepository")
    public EmployeeRepository getEmployeeRepository(){
        return new HibernateEmployeeRepositoryImpl();
    }
*/

}
