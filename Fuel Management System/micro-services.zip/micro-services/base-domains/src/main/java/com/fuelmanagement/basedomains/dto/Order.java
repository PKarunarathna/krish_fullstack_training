package com.fuelmanagement.basedomains.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order {

    private int id;
    private String stationName;
    private String fuelType;
    private int capacity;



}
