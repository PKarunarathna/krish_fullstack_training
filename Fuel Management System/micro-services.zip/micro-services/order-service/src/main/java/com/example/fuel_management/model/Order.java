package com.example.fuel_management.model;

import javax.persistence.*;

@Entity
@Table(name ="orders")
public class Order extends com.fuelmanagement.basedomains.dto.Order {

    @Id
    @Column( nullable = false)
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "station_name")
    private String stationName;
    @Column(name = "fuel_type")
    private String fuelType;
    @Column(name = "capacity")
    private int capacity;

    public Order() {

    }

    public Order(int id, String stationName, String fuelType, int capacity) {
        super();
        this.id = id;
        this.stationName = stationName;
        this.fuelType = fuelType;
        this.capacity = capacity;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
}
