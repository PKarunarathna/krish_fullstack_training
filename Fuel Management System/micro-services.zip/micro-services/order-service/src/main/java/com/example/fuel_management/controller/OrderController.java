package com.example.fuel_management.controller;


import com.example.fuel_management.exception.ResourceNotFoundException;
import com.example.fuel_management.kafka.OrderProducer;
import com.example.fuel_management.model.Order;
//import com.fuelmanagement.basedomains.dto.Order;
import com.example.fuel_management.repository.OrderRepository;
import com.fuelmanagement.basedomains.dto.OrderEvent;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1")
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;

    private OrderProducer orderProducer;

    public OrderController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

 /*
    @PostMapping("/orders")
    public String placeOrder(@RequestBody Order order){
        order.setId(Integer.parseInt(UUID.randomUUID().toString()));

        OrderEvent orderEvent=new OrderEvent();
        orderEvent.setStatus("PENDING");
        orderEvent.setMessage("Order is pending");
        orderEvent.setOrder(order);

        orderProducer.sendMessage(orderEvent);
        return "Order submitted successfully";

    }
*/

    //get all orders
    @GetMapping("/orders")
    public List<Order> getAllOrders(){
        return orderRepository.findAll();
    }


    //create order REST API
    @PostMapping("/orders")
    public Order createOrder(@RequestBody Order order){
        return  orderRepository.save(order);
    }




    //get Order details by id
    @GetMapping("/orders/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable int id){
        Order order=orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not exist with id:"+ id));
        return  ResponseEntity.ok(order);
    }

    @PutMapping("/orders/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable int id,@RequestBody Order orderDetails){
        Order order=orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not exist with id:"+ id));
        order.setCapacity(orderDetails.getCapacity());
        order.setFuelType(orderDetails.getFuelType());
  
        Order updatedOrder = orderRepository.save(order);
        return ResponseEntity.ok(updatedOrder);

    }




}
