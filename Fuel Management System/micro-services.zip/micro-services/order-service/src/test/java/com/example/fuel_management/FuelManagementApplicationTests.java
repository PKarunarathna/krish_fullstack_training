package com.example.fuel_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
