package com.fuelmanagement.dispatchservice.scheduleOrder;

import java.time.LocalDate;

public class OrderSchedule {

    private int RefId;
    private int stationID;
    private LocalDate scheduledDate;

     
}
