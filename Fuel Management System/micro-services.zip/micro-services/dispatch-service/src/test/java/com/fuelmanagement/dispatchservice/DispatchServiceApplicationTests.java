package com.fuelmanagement.dispatchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DispatchServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
