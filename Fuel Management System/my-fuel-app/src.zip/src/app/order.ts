export class Order {
    id: number=0;
    stationName: string="";
    fuelType: string="";
    capacity: number= 0 ; 
     
}
