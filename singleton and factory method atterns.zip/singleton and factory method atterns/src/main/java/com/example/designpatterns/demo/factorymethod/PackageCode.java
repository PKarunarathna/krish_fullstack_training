package com.example.designpatterns.demo.factorymethod;

public enum PackageCode {
    BASIC,SILVER,PLATINUM
}

