package com.example.designpatterns.demo.factorymethod;

public class BridesmaidDeco extends Decoration {
    public  String toString(){
        return "Bridal decoration";
    }
}
