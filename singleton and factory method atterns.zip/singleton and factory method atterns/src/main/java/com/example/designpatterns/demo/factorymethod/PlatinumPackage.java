package com.example.designpatterns.demo.factorymethod;

public class PlatinumPackage extends Package{
    @Override
    protected void createPackage() {
        decorations.add(new BridalDeco());
        decorations.add(new BridesmaidDeco());
        decorations.add(new FlowergirlDeco());
        decorations.add(new ParentDeco());
    }
}
