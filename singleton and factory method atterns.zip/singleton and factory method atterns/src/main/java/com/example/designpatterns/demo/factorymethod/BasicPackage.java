package com.example.designpatterns.demo.factorymethod;


public class BasicPackage extends Package{


    @Override
    protected void createPackage() {
        decorations.add(new BridalDeco());
    }
}
