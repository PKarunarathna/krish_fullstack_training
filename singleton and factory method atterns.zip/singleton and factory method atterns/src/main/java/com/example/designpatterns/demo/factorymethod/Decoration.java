package com.example.designpatterns.demo.factorymethod;

public abstract class Decoration {
}
