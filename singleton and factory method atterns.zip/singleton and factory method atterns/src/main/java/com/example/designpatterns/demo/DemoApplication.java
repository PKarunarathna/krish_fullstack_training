package com.example.designpatterns.demo;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.designpatterns.demo.factorymethod.Package;
import com.example.designpatterns.demo.factorymethod.PackageCode;
import com.example.designpatterns.demo.factorymethod.PackageFactory;

//@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {

		Package aPackage= PackageFactory.createPackage(PackageCode.BASIC);
		System.out.println(aPackage);

		Package aPackage1= PackageFactory.createPackage(PackageCode.PLATINUM);
		System.out.println(aPackage1);

	}

}
