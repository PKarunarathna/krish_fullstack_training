package com.example.designpatterns.demo.factorymethod;

public class FlowergirlDeco extends Decoration{

    public  String toString(){
        return "Flowergirl decoration";
    }

}
