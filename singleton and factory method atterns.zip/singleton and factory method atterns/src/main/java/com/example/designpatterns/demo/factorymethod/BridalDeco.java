package com.example.designpatterns.demo.factorymethod;

public class BridalDeco extends Decoration{
    public  String toString(){
        return "Bridal decoration";
    }
}
