package com.example.designpatterns.demo.factorymethod;

public class ParentDeco extends Decoration{

    public  String toString(){
        return "Parents' decoration";
    }
}
